# -*- coding: utf-8 -*-
"""
Created on Thu Sep 24 12:55:05 2020

@author: SHARATH.R
"""
from flask import Flask,request
import numpy as np
import pandas as pd
import pickle
import flasgger
from flasgger import Swagger    

app = Flask(__name__)
Swagger(app)
pickle_in = open("classifier.pkl",'rb')
classifier = pickle.load(pickle_in)

@app.route('/')
def getting_started():
    return 'Lets start the authentication process'

@app.route('/predict')
def authentication_process():
    """ Let's authenticate the bank notes
    This is using docstrings for authentication
    ---
    parameters:
        - name: variance
          in: query
          type: number
          required: true
        - name: skewness
          in: query
          type: number
          required: true
        - name: curtosis
          in: query
          type: number
          required: true
        - name: entropy
          in: query
          type: number
          required: true
    responses:
        200:
            description: The output values
    """        
    variance = request.args.get('variance')
    skewness = request.args.get('skewness')
    curtosis = request.args.get('curtosis')
    entropy = request.args.get('entropy')
    prediction = classifier.predict([[variance,skewness,curtosis,entropy]])
    return "My prediction is:" + str(prediction)

@app.route('/predict_file',methods = ["POST"])
def authentication_process_file():
    """ Let's authenticate the bank notes
    This is using docstring
    ---
    parameters:
        - name: file
          in: formData
          type: file
          required: true
    responses:
        200:
            description: The output values
    """        
    df_test = pd.read_csv(request.files.get("file"))
    prediction_test = classifier.predict(df_test)    
    return "My predicted values of test cases are :" + str(list(prediction_test))




if __name__ == '__main__':
    app.run()